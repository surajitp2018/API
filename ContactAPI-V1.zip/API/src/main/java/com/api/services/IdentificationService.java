package com.api.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.domain.Identification;
import com.api.repository.IdentificationRepository;


@Service
public class IdentificationService {

	@Autowired
	private IdentificationRepository identificationRepository;
	
	public Identification getIdentificationById(int Id) {
		return identificationRepository.findOne(Id);
	}
	public String addIndentification(Identification indentification) {
		identificationRepository.save(indentification);
		return "Data Added";
	}
	public String deleteIndentification(int Id) {
		identificationRepository.delete(Id);
		return "Data Deleted";
	}
	public String updateIndentification(Identification indentification) {
		identificationRepository.save(indentification);
		return "Data Updated";
	}
}
