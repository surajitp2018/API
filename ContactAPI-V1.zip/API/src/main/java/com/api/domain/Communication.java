package com.api.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Communication")
public class Communication {
	
	/*@Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COMM_SEQ")
    @SequenceGenerator(sequenceName = "MY_COMM_SEQ", allocationSize = 1, name = "COMM_SEQ")
	@Column(name = "id", unique = true, nullable = false)
	private int id;
	@Column(name = "Type",length = 200)
	private String Type;
	@Column(name = "Value",length = 200)
	private String Value;
	@Column(name = "Preferred",length = 200)
	private String Preferred;
	
	public Communication(){
		
	}
	public Communication(String type,String value,String preferred){
	this.Type=type;
	this.Value=value;
	this.Preferred=preferred;
	}
	
	@ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
    @JoinColumn(name = "identificationId")
	@JsonIgnore
    private Identification identity;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		this.Type = type;
	}
	public String getValue() {
		return Value;
	}
	public void setValue(String value) {
		this.Value = value;
	}
	public String getPreferred() {
		return Preferred;
	}
	public void setPreferred(String preferred) {
		this.Preferred = preferred;
	}
	public Identification getIdentity() {
		return identity;
	}
	public void setIdentity(Identification identity) {
		this.identity = identity;
	}
	@Override
	public String toString() {
		return "Communication [id=" + id + ", type=" + Type + ", value=" + Value + ", preferred=" + Preferred
				+ ", identity=" + identity + "]";
	}

	
	

}
