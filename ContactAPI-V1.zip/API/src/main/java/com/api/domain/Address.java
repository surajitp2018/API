package com.api.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "Address")
public class Address {
	
	/*@Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ADD_SEQ")
    @SequenceGenerator(sequenceName = "MY_ADD_SEQ", allocationSize = 1, name = "ADD_SEQ")
	@Column(name = "id", unique = true, nullable = false)
	private int id;
	@Column(name = "type",length = 200)
	private String type;
	@Column(name = "phoneNumber",length = 200)
	private String phoneNumber;
	@Column(name = "street",length = 200)
	private String street;
	@Column(name = "unit",length = 200)
	private String unit;
	@Column(name = "city",length = 200)
	private String city;
	@Column(name = "state",length = 200)
	private String state;
	@Column(name = "zipcode",length = 200)
	private String zipcode;
    
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
    @JoinColumn(name = "identificationId")
    @JsonIgnore
    private Identification identification;
    
    public Address(){

    }
 
    public Address(String type,String phoneNumber,String street,String unit,String city,String state,String zipcode){
    	this.type=type;
    	this.phoneNumber=phoneNumber;
    	this.street=street;
    	this.unit=unit;
    	this.city=city;
    	this.state=state;
    	this.zipcode=zipcode;
    }

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public Identification getIdentification() {
		return identification;
	}
	public void setIdentification(Identification identification) {
		this.identification = identification;
	}
	@Override
	public String toString() {
		return "Address [id=" + id + ", type=" + type + ", phoneNumber=" + phoneNumber + ", street=" + street
				+ ", unit=" + unit + ", city=" + city + ", state=" + state + ", zipcode=" + zipcode
				+ ", identification=" + identification + "]";
	}

	
   
}
