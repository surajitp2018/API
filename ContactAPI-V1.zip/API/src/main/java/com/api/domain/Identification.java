package com.api.domain;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Identification")
public class Identification {
	
/*	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "IDE_SEQ")
    @SequenceGenerator(sequenceName = "MY_Iden_SEQ", allocationSize = 1, name = "IDE_SEQ")
	@Column(name = "id", unique = true, nullable = false)
	private int id;
	@Column(name = "FirstName",length = 200)
	private String FirstName;
	@Column(name = "LastName",length = 200)
	private String LastName;
	@Column(name = "DOB",length = 200)
	private Date DOB;
	@Column(name = "Gender",length = 200)
	private String Gender;
	@Column(name = "Title",length = 200)
	private String Title;
	
	 public Identification(){
	    }
	    
	 public Identification(String firstName, String lastName,Date dob, String gender,String title,Set<Address> address,Set<Communication> communication){
	    	this.FirstName = firstName;
	    	this.LastName = lastName;
	    	this.DOB = dob;
	    	this.Gender = gender;
	    	this.Title = title;
	    	this.address = address;
	    	this.communication = communication;
	}
	
	@OneToMany(mappedBy = "identification", cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
    private Set<Address> address;
	
	@OneToMany(mappedBy = "identity", cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
    private Set<Communication> communication;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		this.FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		this.LastName = lastName;
	}

	public Date getDob() {
		return DOB;
	}

	public void setDob(Date dob) {
		this.DOB = dob;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		this.Gender = gender;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		this.Title = title;
	}

	public Set<Address> getAddress() {
		return address;
	}

	public void setAddress(Set<Address> address) {
		this.address = address;
	}

	public Set<Communication> getCommunication() {
		return communication;
	}

	public void setCommunication(Set<Communication> communication) {
		this.communication = communication;
	}

	@Override
	public String toString() {
		return "Identification [id=" + id + ", FirstName=" + FirstName + ", LastName=" + LastName + ", DOB=" + DOB
				+ ", Gender=" + Gender + ", Title=" + Title + ", address=" + address + ", communication="
				+ communication + "]";
	}

	
}
