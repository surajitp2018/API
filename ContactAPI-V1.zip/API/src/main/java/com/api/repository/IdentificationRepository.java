package com.api.repository;

import org.springframework.data.repository.CrudRepository;
import com.api.domain.Identification;

public interface IdentificationRepository  extends CrudRepository<Identification, Integer>{

}
