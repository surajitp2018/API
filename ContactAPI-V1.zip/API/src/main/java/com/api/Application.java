package com.api;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.api.domain.Address;
import com.api.domain.Communication;
import com.api.domain.Identification;
import com.api.repository.IdentificationRepository;

@SpringBootApplication
@EnableConfigurationProperties()

//public class Application {
public class Application implements CommandLineRunner {

	@Autowired
	private IdentificationRepository identificationRepository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	private void dataBuilder() {
		
		Identification identification = new Identification();
		Address address= new Address();
		Communication communication= new Communication();
		identification.setFirstName("Bob");
		identification.setLastName("Frederick");
		identification.setDob(new Date());
		identification.setGender("M");
		identification.setTitle("Manager");
		address.setType("Home");
		address.setPhoneNumber("1234569999");
		address.setUnit("1 a");
		address.setStreet("Bla");
		address.setCity("Phoenix");
		address.setState("AZ");
		address.setZipcode("12345");
		address.setIdentification(identification);
		Set<Address> addressSet = new HashSet<>();
		addressSet.add(address);
		identification.setAddress(addressSet);
		communication.setType("email");
		communication.setValue("test@gmail.com");
		communication.setPreferred("Yes");
		communication.setIdentity(identification);
		Set<Communication> communicationSet = new HashSet<>();
		communicationSet.add(communication);
		identification.setCommunication(communicationSet);
		identificationRepository.save(identification);
	}
	@Override
	public void run(String... args) throws Exception {
		dataBuilder();
	}
}