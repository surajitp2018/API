package com.api.response;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


import com.api.domain.Address;
import com.api.domain.Communication;

public class ContactResponse implements Serializable {
	
	public ContactResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	private int id;
	private String firstName;
	private String lastName;
	private Date dob;
	private String gender;
	private String title;
	private List<Address> address;
	private List<Communication> communication;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public List<Communication> getCommunication() {
		return communication;
	}
	public void setCommunication(List<Communication> communication) {
		this.communication = communication;
	}
	
	
}
