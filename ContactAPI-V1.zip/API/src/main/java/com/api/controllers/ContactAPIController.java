package com.api.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.http.ResponseEntity;
//import org.springframework.http.HttpStatus;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.api.domain.Address;
import com.api.domain.Communication;
import com.api.domain.Identification;
import com.api.repository.IdentificationRepository;
import com.api.response.ContactResponse;
import com.api.services.IdentificationService;

@RestController
@RequestMapping("/contact")
public class ContactAPIController {
	@Autowired
	IdentificationService identificationService;
	@Autowired
	private IdentificationRepository identificationRepository;
	
	@GetMapping("/get/{id}")
	@ResponseBody
	public ContactResponse getContactData(@PathVariable int id) {	
		Identification identification = null;
		ContactResponse contactResponse = new ContactResponse();
		try {
			identification=identificationService.getIdentificationById(id);

			List<Communication> communicationList = new ArrayList<Communication>();
			List<Address> addressList = new ArrayList<Address>();
			communicationList.addAll(identification.getCommunication());
			addressList.addAll(identification.getAddress());
			contactResponse.setAddress(addressList);
			contactResponse.setCommunication(communicationList);
			contactResponse.setDob(identification.getDob());
			contactResponse.setFirstName(identification.getFirstName());
			contactResponse.setLastName(identification.getLastName());
			contactResponse.setGender(identification.getGender());
			contactResponse.setTitle(identification.getTitle());
		}catch (Exception e) {
			e.printStackTrace();
		}
		return contactResponse;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String addContactData(@RequestBody Identification identification) {
		
		Identification identificationObj = new Identification();
		
		identificationObj.setFirstName(identification.getFirstName());
		identificationObj.setLastName(identification.getLastName());
		identificationObj.setDob(identification.getDob());
		identificationObj.setGender(identification.getGender());
		identificationObj.setTitle(identification.getTitle());
		Set<Address> addressSet=identification.getAddress();
		Set<Address> addressFinalSet = new HashSet<Address>();
		for (Address adrressObj : addressSet) {
			adrressObj.setIdentification(identificationObj);
			addressFinalSet.add(adrressObj);
		}
		identificationObj.setAddress(addressFinalSet);
		
		Set<Communication> communicationSet=identification.getCommunication();
		Set<Communication> communicationFinalSet = new HashSet<Communication>();
		for (Communication communicationObj : communicationSet) {
			communicationObj.setIdentity(identificationObj);
			communicationFinalSet.add(communicationObj);
		}
		identificationObj.setCommunication(communicationFinalSet);
		
		return identificationService.addIndentification(identificationObj);
	
	}
	
	@DeleteMapping("delete/{id}")
	public String deleteArticle(@PathVariable int id) {
		return identificationService.deleteIndentification(id);
	}
	
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	public String updateContactData(@PathVariable int id, @RequestBody Identification identification) {
		
		Identification identificationObj = new Identification();
		
		identificationObj.setId(id);
		identificationObj.setFirstName(identification.getFirstName());
		identificationObj.setLastName(identification.getLastName());
		identificationObj.setDob(identification.getDob());
		identificationObj.setGender(identification.getGender());
		identificationObj.setTitle(identification.getTitle());
		Set<Address> addressSet=identification.getAddress();
		Set<Address> addressFinalSet = new HashSet<Address>();
		for (Address adrressObj : addressSet) {
			adrressObj.setIdentification(identificationObj);
			addressFinalSet.add(adrressObj);
		}
		identificationObj.setAddress(addressFinalSet);
		
		Set<Communication> communicationSet=identification.getCommunication();
		Set<Communication> communicationFinalSet = new HashSet<Communication>();
		for (Communication communicationObj : communicationSet) {
			communicationObj.setIdentity(identificationObj);
			communicationFinalSet.add(communicationObj);
		}
		identificationObj.setCommunication(communicationFinalSet);
		
		return identificationService.updateIndentification(identificationObj);
	
	}
}


